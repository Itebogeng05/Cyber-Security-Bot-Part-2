﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace CyberSecurityBot_prt2
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
